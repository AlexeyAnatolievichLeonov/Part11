#include <Loader.hh>
#include <DataWriter.hh>

int main(int argc, char** argv) 
{
 OutFile::Open();
	
 Loader* loader = new Loader(argc,argv,OutFile::fout);

 delete loader;
	
 OutFile::Close();

//system("pause");
 return 0;
}

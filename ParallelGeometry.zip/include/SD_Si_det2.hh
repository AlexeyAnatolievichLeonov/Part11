#ifndef SD_Si_det2_HH
#define SD_Si_det2_HH

#include <G4Material.hh>
#include <G4SDManager.hh>
#include "G4NistManager.hh"
#include "G4VSensitiveDetector.hh"
#include "G4Step.hh"
#include "G4HCofThisEvent.hh"
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdio.h>

#include "SD_Si_det2_hit.hh"

class SD_Si_det2 : public G4VSensitiveDetector
{
 public:
  SD_Si_det2(G4String SDname);
  ~SD_Si_det2();

  void Initialize(G4HCofThisEvent* HCE);
  G4bool ProcessHits(G4Step* astep, G4TouchableHistory*); 
  void EndOfEvent(G4HCofThisEvent* HCE);

  G4double GetSumE(G4int i) const {return SumE[i];}
  void AddSumE(double e, G4int i) {SumE[i]+=e;}
  G4double GetCopyNum(G4int i) const {return CopyNum[i];}
  void SetCopyNum(G4int i) {CopyNum[i]=i+1;}
  
 private:
  std::ofstream hit_SD_Si_det[2];
  G4double SumE[2];
  G4int CopyNum[2];
  
  SD_Si_det2_hitCollection *hitCollection;
  G4int collectionID;    
};

#endif


#ifndef CPROJECT_DET_RO_GEOMETRY_HH
#define CPROJECT_DET_RO_GEOMETRY_HH

#include "Si_det2_Parameterisation.hh"
#include <G4VUserPhysicsList.hh>
#include <G4UserLimits.hh>
#include <G4SDManager.hh>
#include <G4VUserParallelWorld.hh>
#include "SD_Si_det2.hh"
#include "G4SystemOfUnits.hh"
#include "G4SolidStore.hh"
#include "G4LogicalVolumeStore.hh"
#include "G4PhysicalVolumeStore.hh"
#include "G4NistManager.hh"
#include "G4PVPlacement.hh"
#include "G4PVParameterised.hh"
#include "G4Box.hh"
#include "G4Tubs.hh"
#include <G4RunManager.hh>
#include <G4GeometryManager.hh>
#include <G4UImanager.hh>
#include <G4VReadOutGeometry.hh>
#include "G4VisAttributes.hh"
#include "G4Cache.hh"
#include "G4AutoDelete.hh"

#define SU *mm

class MyROGeom  : public G4VUserParallelWorld
{
 public:

  virtual void Construct();
    
  G4Box*		      Si_box2;
  G4LogicalVolume*            Si_log2;
  G4VPhysicalVolume*          Si_pvpl2;
  G4ThreeVector		      Si_vect;
    
  G4Box*		      Si_det2_box;
  G4LogicalVolume*            Si_det2_log;
  G4VPhysicalVolume*          Si_det2_pvpl;            

  MyROGeom(G4String);
  virtual ~MyROGeom();

 private:
  G4String ROname;
};

#endif //CPROJECT_DET_RO_GEOMETRY_HH

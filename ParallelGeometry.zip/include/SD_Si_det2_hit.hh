#ifndef SD_Si_det2_hit_h
#define SD_Si_det2_hit_h 1

#include <G4VHit.hh>
#include <G4THitsCollection.hh>
#include <G4Allocator.hh>
#include <G4ThreeVector.hh>

class SD_Si_det2_hit : public G4VHit
{
 public:
  SD_Si_det2_hit();
  ~SD_Si_det2_hit();
  SD_Si_det2_hit(const SD_Si_det2_hit&);
  const SD_Si_det2_hit& operator=(const SD_Si_det2_hit&);
  G4int operator==(const SD_Si_det2_hit&) const;
  
  inline void* operator new(size_t);
  inline void  operator delete(void *aHit);

  void Draw();  
  void Print();
  
  void SetEdep(const double e) {this->eDep_hit=e;}
  G4double GetEdep() const {return eDep_hit;}

  void SetLayerNumber(const int c) {this->layerNumber_hit=c;}  
  G4int GetLayerNumber() const {return layerNumber_hit;}
  
 private:
  G4int layerNumber_hit;
  G4double eDep_hit;
};

typedef G4THitsCollection<SD_Si_det2_hit> SD_Si_det2_hitCollection;

extern G4Allocator<SD_Si_det2_hit> hitAllocatorSD2;

inline void* SD_Si_det2_hit::operator new(size_t)
{
 void* aHit;
 aHit = (void*) hitAllocatorSD2.MallocSingle();
 return aHit;
}

inline void SD_Si_det2_hit::operator delete(void* aHit)
{
 hitAllocatorSD2.FreeSingle((SD_Si_det2_hit*) aHit);
}

#endif

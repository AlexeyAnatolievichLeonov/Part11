#include "G4UnitsTable.hh"
#include "G4VVisManager.hh"
#include "G4Circle.hh"
#include "G4Color.hh"
#include "G4VisAttributes.hh"

#include "SD_Si_det2_hit.hh"

G4Allocator<SD_Si_det2_hit> hitAllocatorSD2;

SD_Si_det2_hit::SD_Si_det2_hit() : eDep_hit(0), layerNumber_hit(0) {}
SD_Si_det2_hit::~SD_Si_det2_hit(){}

SD_Si_det2_hit::SD_Si_det2_hit(const SD_Si_det2_hit& right):G4VHit()
{
 eDep_hit        = right.eDep_hit;
 layerNumber_hit = right.layerNumber_hit;
}

const SD_Si_det2_hit& SD_Si_det2_hit::operator=(const SD_Si_det2_hit& right)
{
 eDep_hit        = right.eDep_hit;
 layerNumber_hit = right.layerNumber_hit;
 return *this;
}

G4int SD_Si_det2_hit::operator==(const SD_Si_det2_hit& right) const
{
 return (this==&right) ? 1 : 0;
}

void SD_Si_det2_hit::Draw()
{
}

void SD_Si_det2_hit::Print()
{
 G4cout      << "eDep: "        << eDep_hit << G4endl;
 G4cout      << "layerNumber: " << layerNumber_hit << G4endl;
}



#include "SD_Si_det2.hh"

SD_Si_det2 :: SD_Si_det2 (G4String SDname) : G4VSensitiveDetector(SDname) 
{
 collectionName.insert("SD_Si_det2_hitCollection"); 
 
 G4String filename[2];
 char str[2];
 G4int i;
 for (i=0;i<2;i++)
 {
  filename[i] ="hit_Si_det2_";
  sprintf(str,"%d",i+1);
  filename[i]+=str;
  filename[i]+=".dat";
//  G4cout<<filename[i]<<" "<<G4endl;
  hit_SD_Si_det[i].open(filename[i],std::fstream::out);
 }
 
 for (i=0; i<2; i++) 
 {SumE[i]=0.; CopyNum[i]=0;}
}

SD_Si_det2 :: ~SD_Si_det2()
{
 for (G4int i=0; i<2; i++) 
 {hit_SD_Si_det[i].close();}
}

void SD_Si_det2 :: Initialize(G4HCofThisEvent* HCE)
{
 hitCollection = new SD_Si_det2_hitCollection(GetName(), collectionName[0]);
 
 static G4int HCID2=-1;
 if (HCID2<0) HCID2 = GetCollectionID(0);
 HCE->AddHitsCollection(HCID2,hitCollection);
}

extern G4int eventID;

void SD_Si_det2 :: EndOfEvent(G4HCofThisEvent* HCE)
{
 G4int i;
 for (i=0; i<2; i++) 
 {hit_SD_Si_det[i] << std::setw(10) << this->GetSumE(i) << std::setw(10) << this->GetCopyNum(i) << G4endl;}
 for (i=0; i<2; i++) {SumE[i]=0.;}

 G4SDManager* SDman= G4SDManager::GetSDMpointer();
 G4int hitsCollID= SDman->GetCollectionID("SD_Si_det2_hitCollection");
 SD_Si_det2_hitCollection* THC = NULL;
 THC = (SD_Si_det2_hitCollection*)(HCE->GetHC(hitsCollID));
 if (THC)
 {
  G4int n_hit=THC->entries();
  for (i=0; i<n_hit; i++)
  {
   SD_Si_det2_hit* hit = (*THC)[i];
   G4cout<<"collection ID="<<hitsCollID<<" "<<THC->GetName()<<" "<<THC->GetSDname()<<" "<<hit->GetEdep()<<" "<<hit->GetLayerNumber()<<G4endl;
  }
 }
}

G4bool SD_Si_det2 :: ProcessHits(G4Step* step, G4TouchableHistory*)
{
 G4TouchableHandle touchable = step->GetPreStepPoint()->GetTouchableHandle();
 G4int copyNo   = touchable->GetVolume(0)->GetCopyNo();
 G4double edep  = 0.;
 edep           = step->GetTotalEnergyDeposit();
 this->AddSumE(edep,copyNo);
 this->SetCopyNum(copyNo);
 
 SD_Si_det2_hit *aHit = new SD_Si_det2_hit();
 aHit->SetEdep(step->GetTotalEnergyDeposit());
 aHit->SetLayerNumber(step->GetPreStepPoint()->GetTouchableHandle()->GetVolume(0)->GetCopyNo());
 hitCollection->insert(aHit);
 
 return true; 
}


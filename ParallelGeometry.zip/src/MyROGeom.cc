#include "MyROGeom.hh"

using namespace std;

//#define SU *mm

MyROGeom::MyROGeom(G4String name):G4VUserParallelWorld(name)
{
 this->ROname=name;
}

MyROGeom::~MyROGeom(){}

void MyROGeom::Construct()
{
 G4VPhysicalVolume* ghostWorld = GetWorld();
 G4LogicalVolume* worldLogical= ghostWorld->GetLogicalVolume();

// Параметры мира 2

 G4RotationMatrix* ZERO_RM = new G4RotationMatrix(0, 0, 0);	
 Si_box2 = new G4Box("Si_vol2", 10. * cm, 1. * cm, 1. * cm);
 Si_log2 = new G4LogicalVolume(Si_box2, 0,"Si_vol_log2");	
 Si_vect = G4ThreeVector(0, 0, 2.*cm);
 Si_pvpl2 = new G4PVPlacement(ZERO_RM, Si_vect, Si_log2, "Si_vol_pvpl2", worldLogical, false, 0, false);
	
 Si_det2_box = new G4Box("Si_det2_vol", 5. * cm, 1. * cm, 1. * cm);
 Si_det2_log = new G4LogicalVolume(Si_det2_box, 0,"Si_det2_vol_log");		
	
 G4VPVParameterisation* Si_det2 = new Si_det2_Parameterisation();
 Si_det2_pvpl = new G4PVParameterised("Si_det2", Si_det2_log, Si_log2, kXAxis, 2, Si_det2);

 G4SDManager* sdman = G4SDManager::GetSDMpointer();
 SD_Si_det2* sensitive_Si_det2 = new SD_Si_det2("/mySi_det2");
 sdman->AddNewDetector(sensitive_Si_det2);
 Si_det2_log->SetSensitiveDetector(sensitive_Si_det2);
}
